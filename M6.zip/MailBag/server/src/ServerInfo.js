"use strict";
exports.__esModule = true;
exports.serverInfo = void 0;
var path = require("path");
var fs = require("fs");
var rawInfo = fs.readFileSync(path.join(__dirname, "../ServerInfo.json"));
exports.serverInfo = JSON.parse(rawInfo);
